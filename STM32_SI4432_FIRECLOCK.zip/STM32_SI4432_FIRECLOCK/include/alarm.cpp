#include "alarm.h"

/*******************************************************************************/

decomptime::decomptime(uint8_t min, uint8_t hour, uint8_t weekday)
{
    //    time[0]=sec;
    time[0] = min;
    time[1] = hour;
    //    time[3]=days;
    //    time[4]=mounths;
    //    time[5]=years;
    time[2] = weekday;
};

uint8_t decomptime::min()
{
    return time[0];
}
uint8_t decomptime::hour()
{
    return time[1];
}
uint8_t decomptime::weekday()
{
    return time[2];
}

/*******************************************************************************/

void alarm::create(decomptime *time, Effects *Eff)
{
    event = new task(this, time, Eff);
}
void alarm::check()
{
    event->CheckOrRun();
}

void alarm::next() {}

/*******************************************************************************/

void task::finish()
{
    // run

    parent->next();
}

void task::CheckOrRun()
{
    if (started) {
        if ((60 + minute() - time_stop) % 60 > 30) {
            Serial.println(minute()- time_stop);
//            Serial.println("------------------------------------------------------");
            started = false;
            EFF->Set_Effect(0);
        }
    } else {
        uint8_t Weekday = weekday();
        Weekday = (7 + Weekday - 1) % 7 + 1;
        Weekday = 1 << (7 - Weekday);
        if (hour() == time->hour() && minute() == time->min() && Weekday & time->weekday() && !(time->hour() == time->min() && time->min() == 0))
        {
            EFF->Set_Effect(8);
            started = true;

            EFF->Set_Scale(0);
            EFF->Run();
            
            time_stop = minute();
            Serial.println(time_stop);
            Serial.println("------------------------------------------------------");
            
        }
    }
}