
#ifndef LIBS
#define LIBS

#include "Arduino.h"
#include <TimeLib.h>
#include <queue>
#include "Effects.h"

#endif

struct task;
struct alarm;

struct decomptime
{
    uint8_t time[3]; // sec, min, hours, days, mounths, yeats
    decomptime(uint8_t hour, uint8_t min,  uint8_t weekday);
    uint8_t min();
    uint8_t hour();
    uint8_t weekday();
    void Set_min(uint8_t minute) {
        time[0] = minute;
    }
    void Set_hour(uint8_t hour) {
        time[1] = hour;
    }
    void Set_weekday(uint8_t weekday) {
        time[2] = weekday;
    }
};

struct alarm
{
    task *event;

    alarm(){}

    void create(decomptime *_time, Effects *Eff);

    void check();
    
    void next();
};

struct task
{ // event
    alarm *parent;
    uint32_t time_stop=0;
    decomptime *time;
    Effects *EFF;
    task(alarm *_parent, decomptime *_time, Effects *_EFF) : parent(_parent), time(_time), EFF(_EFF) {} // TO-DO

    void finish();
    void CheckOrRun();
};